import 'package:flutter/material.dart';
import 'core/database/case_db_service.dart';
import 'core/database/chamber_db_service.dart';
import 'core/database/knowledge_db_service.dart';
import 'features/home/screens/home_screen.dart';

void main() async {
  // ফ্ল্যাটার ইঞ্জিন এবং বাইন্ডিং নিশ্চিত করা (অফলাইন ডাটাবেসের জন্য আবশ্যিক)
  WidgetsFlutterBinding.ensureInitialized();

  // অ্যাপ ওপেন হওয়ার সাথে সাথেই ব্যাকগ্রাউন্ডে ৩টি কোর ডাটাবেস সার্ভিস সচল করা
  final caseDb = CaseDbService();
  final chamberDb = ChamberDbService();
  final knowledgeDb = KnowledgeDbService();

  await caseDb.database;
  await chamberDb.database;
  await knowledgeDb.database;

  // নলেজ লাইব্রেরিতে কিছু হোমিওপ্যাথিক ডামি ডাটা ইনিশিয়াল করা (যদি আগে থেকে খালি থাকে)
  await knowledgeDb.initDemoDataIfNeeded();

  runApp(const PrithaHomeoRecordApp());
}

class PrithaHomeoRecordApp extends StatelessWidget {
  const PrithaHomeoRecordApp({super.key});

  @override
  Widget build(BuildContext context) {
    // চোখের সুরক্ষার জন্য আমাদের সিগনেচার থিম কালার স্কিম
    const Color bgAlabaster = Color(0xFFF5F2EB); // পেপার ব্যাকগ্রাউন্ড
    const Color primaryDeepPine = Color(0xFF1F3F3F); // ডার্ক পাইন গ্রিন
    const Color textObsidian = Color(0xFF252B2B); // চারকোল টেক্সট

    return MaterialApp(
      title: 'Pritha Homeo Record',
      debugShowCheckedModeBanner: false,
      
      // গ্লোবাল থিম কনফিগারেশন (যাতে পুরো অ্যাপে একই আরামদায়ক লুক থাকে)
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: bgAlabaster,
        colorScheme: ColorScheme.fromSeed(
          seedColor: primaryDeepPine,
          primary: primaryDeepPine,
          background: bgAlabaster,
          surface: Colors.white,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: primaryDeepPine,
          foregroundColor: bgAlabaster,
          elevation: 2,
          centerTitle: false,
          titleTextStyle: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: bgAlabaster,
          ),
        ),
        cardTheme: CardTheme(
          color: Colors.white,
          elevation: 3,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        textTheme: const TextTheme(
          bodyLarge: TextStyle(color: textObsidian),
          bodyMedium: TextStyle(color: textObsidian),
        ),
      ),
      
      // অ্যাপ ওপেন হলেই সরাসরি আমাদের তৈরি ড্যাশবোর্ডে নিয়ে যাবে
      home: const HomeScreen(),
    );
  }
}