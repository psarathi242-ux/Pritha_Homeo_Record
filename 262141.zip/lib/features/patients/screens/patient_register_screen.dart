import 'package:flutter/material.dart';
import '../../../../core/database/patient_db_service.dart';
import '../../../../core/models/patient_model.dart';

class PatientRegisterScreen extends StatefulWidget {
  const PatientRegisterScreen({super.key});

  @override
  State<PatientRegisterScreen> createState() => _PatientRegisterScreenState();
}

class _PatientRegisterScreenState extends State<PatientRegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _occupationController = TextEditingController();
  String _selectedGender = 'Male';

  final PatientDbService _dbService = PatientDbService();

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _occupationController.dispose();
    super.dispose();
  }

  // ডেটাবেসে রোগী সেভ করার মেথড
  void _savePatient() async {
    if (_formKey.currentState!.validate()) {
      final uniqueId = DateTime.now().millisecondsSinceEpoch.toString(); // ইউনিক আইডি তৈরি
      
      final newPatient = PatientModel(
        patientId: uniqueId,
        name: _nameController.text.trim(),
        gender: _selectedGender,
        createdAt: DateTime.now().toIso8601String(),
        phone: _phoneController.text.trim().isEmpty ? null : _phoneController.text.trim(),
        occupation: _occupationController.text.trim().isEmpty ? null : _occupationController.text.trim(),
      );

      await _dbService.insertPatient(newPatient);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('নতুন রোগী সফলভাবে নিবন্ধিত হয়েছে!')),
        );
        Navigator.pop(context, true); // আগের স্ক্রিনে ফিরে যাওয়া এবং সফলতার সংকেত পাঠানো
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('নতুন রোগী নিবন্ধন'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'রোগীর সাধারণ তথ্য',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal),
              ),
              const SizedBox(height: 15),
              
              // রোগীর নাম
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'রোগীর নাম *',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'অনুগ্রহ করে রোগীর নাম লিখুন';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 15),

              // লিঙ্গ নির্বাচন (Gender Dropdown)
              DropdownButtonFormField<String>(
                value: _selectedGender,
                decoration: const InputDecoration(
                  labelText: 'লিঙ্গ *',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.wc),
                ),
                items: const [
                  DropdownMenuItem(value: 'Male', child: Text('পুরুষ (Male)')),
                  DropdownMenuItem(value: 'Female', child: Text('নারী (Female)')),
                  DropdownMenuItem(value: 'Other', child: Text('অন্যান্য (Other)')),
                ],
                onChanged: (value) {
                  if (value != null) {
                    setState(() {
                      _selectedGender = value;
                    });
                  }
                },
              ),
              const SizedBox(height: 15),

              // মোবাইল নাম্বার
              TextFormField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'মোবাইল নাম্বার',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.phone),
                ),
              ),
              const SizedBox(height: 15),

              // পেশা
              TextFormField(
                controller: _occupationController,
                decoration: const InputDecoration(
                  labelText: 'পেশা',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.work),
                ),
              ),
              const SizedBox(height: 30),

              // সেভ বাটন
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  onPressed: _savePatient,
                  icon: const Icon(Icons.save),
                  label: const Text('সংরক্ষণ করুন', style: TextStyle(fontSize: 18)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    foregroundColor: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}