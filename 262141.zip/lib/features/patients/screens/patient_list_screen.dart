import 'package:flutter/material.dart';
import '../../../../core/database/case_db_service.dart';
import '../../../../core/models/patient_model.dart';
import '../../case/screens/case_history_screen.dart';
import 'add_patient_screen.dart';

class PatientListScreen extends StatefulWidget {
  const PatientListScreen({super.key});

  @override
  State<PatientListScreen> createState() => _PatientListScreenState();
}

class _PatientListScreenState extends State<PatientListScreen> {
  final CaseDbService _dbService = CaseDbService();
  List<PatientModel> _patientList = [];
  List<PatientModel> _filteredList = [];
  PatientModel? _selectedPatient; // ট্যাবলেটে ডানপাশের প্যানেলে দেখানোর জন্য নির্বাচিত রোগী
  bool _isLoading = true;
  final _searchController = TextEditingController();

  // চোখের সুরক্ষার থিম কালারসমূহ
  final Color bgAlabaster = const Color(0xFFF5F2EB);
  final Color primaryDeepPine = const Color(0xFF1F3F3F);
  final Color textObsidian = const Color(0xFF252B2B);

  @override
  void initState() {
    super.initState();
    _loadPatients();
  }

  Future<void> _loadPatients() async {
    setState(() => _isLoading = true);
    final data = await _dbService.getAllPatients();
    setState(() {
      _patientList = data;
      _filteredList = data;
      if (data.isNotEmpty && _selectedPatient == null) {
        _selectedPatient = data.first; // ডিফল্টভাবে প্রথম রোগীকে সিলেক্ট করে রাখা
      }
      _isLoading = false;
    });
  }

  void _filterPatients(String query) {
    if (query.isEmpty) {
      setState(() => _filteredList = _patientList);
    } else {
      setState(() {
        _filteredList = _patientList.where((p) {
          final nameMatch = p.name.toLowerCase().contains(query.toLowerCase());
          final phoneMatch = p.phone?.contains(query) ?? false;
          final idMatch = p.patientId.toString() == query;
          return nameMatch || phoneMatch || idMatch;
        }).toList();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // ট্যাবলেটের স্ক্রিন চওড়া (Width > 650) কিনা তা সনাক্ত করা
    final double screenWidth = MediaQuery.of(context).size.width;
    final bool isTablet = screenWidth >= 650;

    return Scaffold(
      backgroundColor: bgAlabaster,
      appBar: AppBar(
        title: const Text('নিবন্ধিত রোগী রেজিস্ট্রি খাতা'),
        backgroundColor: primaryDeepPine,
        foregroundColor: bgAlabaster,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: primaryDeepPine))
          : isTablet
              ? _buildTabletSplitLayout() // ট্যাবলেটের জন্য ২-কলাম লেআউট
              : _buildMobileListLayout(),  // মোবাইলের জন্য সিঙ্গেল লেআউট
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AddPatientScreen()),
          );
          if (result == true) {
            _loadPatients();
          }
        },
        backgroundColor: primaryDeepPine,
        foregroundColor: bgAlabaster,
        icon: const Icon(Icons.person_add_alt_1_rounded),
        label: const Text('নতুন রোগী রেজিস্ট্রি', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
    );
  }

  // 📱 মোবাইল লেআউট (সাধারণ লিস্ট)
  Widget _buildMobileListLayout() {
    return Column(
      children: [
        _buildSearchBar(),
        Expanded(child: _buildPatientListView(isTablet: false)),
      ],
    );
  }

  // 📟 ট্যাবলেট স্প্লিট লেআউট (Master-Detail View)
  Widget _buildTabletSplitLayout() {
    return Row(
      children: [
        // বাম পাশের প্যানেল (রোগীদের তালিকা - ৩৫% জায়গা)
        SizedBox(
          width: 350,
          child: Column(
            children: [
              _buildSearchBar(),
              Expanded(child: _buildPatientListView(isTablet: true)),
            ],
          ),
        ),
        
        // মাঝের ডিভাইডার দাগ
        VerticalDivider(width: 1, thickness: 1, color: primaryDeepPine.withOpacity(0.2)),

        // ডান পাশের প্যানেল (নির্বাচিত রোগীর কেস হিস্ট্রি - ৬৫% জায়গা)
        Expanded(
          child: _selectedPatient == null
              ? Center(
                  child: Text(
                    'বাম পাশের তালিকা থেকে যেকোনো রোগী নির্বাচন করুন',
                    style: TextStyle(color: textObsidian.withOpacity(0.5), fontSize: 16),
                  ),
                )
              : CaseHistoryScreen(patient: _selectedPatient!),
        ),
      ],
    );
  }

  // সার্চ বার উইজেট
  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: TextField(
        controller: _searchController,
        onChanged: _filterPatients,
        decoration: InputDecoration(
          hintText: 'রোগীর নাম, আইডি বা মোবাইল নং...',
          prefixIcon: Icon(Icons.search_rounded, color: primaryDeepPine),
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(vertical: 10),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
        ),
      ),
    );
  }

  // রোগীর তালিকা উইজেট
  Widget _buildPatientListView({required bool isTablet}) {
    if (_filteredList.isEmpty) {
      return const Center(child: Text('কোনো রোগীর তথ্য পাওয়া যায়নি।'));
    }
    return ListView.builder(
      itemCount: _filteredList.length,
      itemBuilder: (context, index) {
        final patient = _filteredList[index];
        final bool isSelected = isTablet && _selectedPatient?.patientId == patient.patientId;

        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: isSelected ? primaryDeepPine.withOpacity(0.15) : Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: isSelected ? Border.all(color: primaryDeepPine, width: 1.5) : null,
          ),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: primaryDeepPine,
              child: Text(
                patient.name.isNotEmpty ? patient.name[0].toUpperCase() : 'P',
                style: TextStyle(color: bgAlabaster, fontWeight: FontWeight.bold),
              ),
            ),
            title: Text(patient.name, style: TextStyle(fontWeight: FontWeight.bold, color: textObsidian)),
            subtitle: Text('বয়স: ${patient.age ?? 'N/A'} | ${patient.gender ?? 'N/A'}\nমোবাইল: ${patient.phone ?? 'N/A'}'),
            isThreeLine: true,
            onTap: () {
              if (isTablet) {
                // ট্যাবলেটে ক্লিক করলে ডানপাশের প্যানেলে সরাসরি ডাটা লোড হবে
                setState(() {
                  _selectedPatient = patient;
                });
              } else {
                // মোবাইলে ক্লিক করলে নতুন স্ক্রিনে নিয়ে যাবে
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CaseHistoryScreen(patient: patient)),
                );
              }
            },
          ),
        );
      },
    );
  }
}