import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import '../../../../core/database/chamber_db_service.dart';
import '../../../../core/database/case_db_service.dart';

class ChamberSettingsScreen extends StatefulWidget {
  const ChamberSettingsScreen({super.key});

  @override
  State<ChamberSettingsScreen> createState() => _ChamberSettingsScreenState();
}

class _ChamberSettingsScreenState extends State<ChamberSettingsScreen> {
  final ChamberDbService _chamberDb = ChamberDbService();
  final CaseDbService _caseDb = CaseDbService();

  final _doctorNameController = TextEditingController();
  final _degreeController = TextEditingController();
  final _chamberNameController = TextEditingController();
  final _chamberAddressController = TextEditingController();
  final _phoneController = TextEditingController();

  bool _isLoading = true;
  bool _isBackingUp = false;

  final Color bgAlabaster = const Color(0xFFF5F2EB);
  final Color primaryDeepPine = const Color(0xFF1F3F3F);
  final Color textObsidian = const Color(0xFF252B2B);

  @override
  void initState() {
    super.initState();
    _loadChamberInfo();
  }

  Future<void> _loadChamberInfo() async {
    final info = await _chamberDb.getChamberInfo();
    if (info != null) {
      _doctorNameController.text = info['doctor_name'] ?? '';
      _degreeController.text = info['degree'] ?? '';
      _chamberNameController.text = info['chamber_name'] ?? '';
      _chamberAddressController.text = info['chamber_address'] ?? '';
      _phoneController.text = info['phone'] ?? '';
    }
    setState(() => _isLoading = false);
  }

  Future<void> _saveChamberInfo() async {
    await _chamberDb.saveChamberInfo({
      'doctor_name': _doctorNameController.text,
      'degree': _degreeController.text,
      'chamber_name': _chamberNameController.text,
      'chamber_address': _chamberAddressController.text,
      'phone': _phoneController.text,
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('চেম্বার সেটিংস সফলভাবে সেভ হয়েছে!')),
      );
    }
  }

  // 💾 ডাটা ব্যাকআপ করার মেথড
  Future<void> _exportBackupData() async {
    setState(() => _isBackingUp = true);
    try {
      final patients = await _caseDb.getAllPatients();
      List<Map<String, dynamic>> backupList = [];

      for (var p in patients) {
        final cases = await _caseDb.getCasesForPatient(p.patientId!);
        backupList.add({
          'patient': p.toMap(),
          'cases': cases.map((c) => c.toMap()).toList(),
        });
      }

      String jsonString = jsonEncode(backupList);
      final directory = Directory('/sdcard/Download');
      if (!await directory.exists()) {
        await directory.create(recursive: true);
      }

      final file = File('${directory.path}/pritha_homeo_backup_${DateTime.now().millisecondsSinceEpoch}.json');
      await file.writeAsString(jsonString);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('ব্যাকআপ ফাইল ট্যাবলেটের Download ফোল্ডারে সেভ হয়েছে:\n${file.path}'),
            duration: const Duration(seconds: 4),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('ব্যাকআপ নিতে সমস্যা হয়েছে: $e')),
        );
      }
    } finally {
      setState(() => _isBackingUp = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgAlabaster,
      appBar: AppBar(
        title: const Text('চেম্বার ব্র্যান্ডিং ও ব্যাকআপ সেটিংস'),
        backgroundColor: primaryDeepPine,
        foregroundColor: bgAlabaster,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: primaryDeepPine))
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: ListView(
                children: [
                  Card(
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('ডাক্তার ও চেম্বারের তথ্য',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: primaryDeepPine)),
                          const SizedBox(height: 15),
                          TextField(
                            controller: _doctorNameController,
                            decoration: const InputDecoration(labelText: 'ডাক্তারের নাম', border: OutlineInputBorder()),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: _degreeController,
                            decoration: const InputDecoration(labelText: 'ডিগ্রী / পদবী', border: OutlineInputBorder()),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: _chamberNameController,
                            decoration: const InputDecoration(labelText: 'চেম্বারের নাম', border: OutlineInputBorder()),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: _chamberAddressController,
                            decoration: const InputDecoration(labelText: 'চেম্বারের ঠিকানা', border: OutlineInputBorder()),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: _phoneController,
                            decoration: const InputDecoration(labelText: 'মোবাইল নম্বর', border: OutlineInputBorder()),
                          ),
                          const SizedBox(height: 15),
                          ElevatedButton.icon(
                            onPressed: _saveChamberInfo,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: primaryDeepPine,
                              foregroundColor: bgAlabaster,
                              minimumSize: const Size(double.infinity, 45),
                            ),
                            icon: const Icon(Icons.save_rounded),
                            label: const Text('তথ্য সেভ করুন'),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Card(
                    color: Colors.white,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('নিরাপত্তা ও ডাটা ব্যাকআপ (Backup)',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: primaryDeepPine)),
                          const SizedBox(height: 8),
                          Text('এক ক্লিকেই সব রোগীর তালিকা ও কেস হিস্ট্রি ফাইল আকারে সেভ করে রাখুন।',
                              style: TextStyle(color: textObsidian.withOpacity(0.7), fontSize: 13)),
                          const SizedBox(height: 15),
                          _isBackingUp
                              ? Center(child: CircularProgressIndicator(color: primaryDeepPine))
                              : ElevatedButton.icon(
                                  onPressed: _exportBackupData,
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.teal[800],
                                    foregroundColor: bgAlabaster,
                                    minimumSize: const Size(double.infinity, 45),
                                  ),
                                  icon: const Icon(Icons.download_rounded),
                                  label: const Text('ডাটা ব্যাকআপ ডাউনলোড করুন (Export Backup)'),
                                ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}