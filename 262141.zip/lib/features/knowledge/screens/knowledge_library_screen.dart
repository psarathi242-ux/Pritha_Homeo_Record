import 'package:flutter/material.dart';
import '../../../../core/database/knowledge_db_service.dart';
import '../../../../core/models/knowledge_model.dart';

class KnowledgeLibraryScreen extends StatefulWidget {
  const KnowledgeLibraryScreen({super.key});

  @override
  State<KnowledgeLibraryScreen> createState() => _KnowledgeLibraryScreenState();
}

class _KnowledgeLibraryScreenState extends State<KnowledgeLibraryScreen> with SingleTickerProviderStateMixin {
  final KnowledgeDbService _dbService = KnowledgeDbService();
  late TabController _tabController;
  final _searchController = TextEditingController();
  
  List<KnowledgeModel> _materiaMedicaList = [];
  List<KnowledgeModel> _anatomyPhysiologyList = [];
  List<KnowledgeModel> _searchResults = [];
  bool _isSearching = false;
  bool _isLoading = true;

  // চোখের সুরক্ষার থিম
  final Color bgAlabaster = const Color(0xFFF5F2EB);
  final Color primaryDeepPine = const Color(0xFF1F3F3F);
  final Color textObsidian = const Color(0xFF252B2B);

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadLibraryData();
  }

  // লাইব্রেরির অফলাইন ডাটাবেস লোড
  Future<void> _loadLibraryData() async {
    setState(() => _isLoading = true);
    final mmData = await _dbService.getKnowledgeBySection('Materia Medica');
    final apData = await _dbService.getKnowledgeBySection('Anatomy_Physiology');
    setState(() {
      _materiaMedicaList = mmData;
      _anatomyPhysiologyList = apData;
      _isLoading = false;
    });
  }

  // রিয়েলটাইম সার্চ ফাংশন
  void _handleSearch(String query) async {
    if (query.trim().isEmpty) {
      setState(() => _isSearching = false);
      return;
    }
    setState(() => _isSearching = true);
    final results = await _dbService.searchKnowledge(query.trim());
    setState(() {
      _searchResults = results;
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Widget _buildBookList(List<KnowledgeModel> items, String emptyMessage) {
    if (items.isEmpty) {
      return Center(child: Text(emptyMessage, style: const TextStyle(color: Colors.grey, fontSize: 16)));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(10),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final book = items[index];
        return Card(
          color: Colors.white,
          margin: const EdgeInsets.symmetric(vertical: 6),
          child: ListTile(
            title: Text(book.subjectTitle, style: TextStyle(fontWeight: FontWeight.bold, color: primaryDeepPine, fontSize: 17)),
            subtitle: book.authorOrSource != null ? Text('লেখক/উৎস: ${book.authorOrSource}') : null,
            trailing: const Icon(Icons.menu_book_rounded, size: 20),
            onTap: () => _showBookDetailsDialog(book),
          ),
        );
      },
    );
  }

  void _showBookDetailsDialog(KnowledgeModel book) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: bgAlabaster,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(book.subjectTitle, style: TextStyle(color: primaryDeepPine, fontWeight: FontWeight.bold)),
            if (book.authorOrSource != null)
              Text('লেখক: ${book.authorOrSource}', style: const TextStyle(fontSize: 13, color: Colors.grey)),
          ],
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (book.keyIndications != null && book.keyIndications!.isNotEmpty) ...[
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: Colors.amber.shade50, border: Border.all(color: Colors.amber.shade300), borderRadius: BorderRadius.circular(5)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('🎯 নির্দেশক কি-নোট লক্ষণাবলি:', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.brown)),
                        const SizedBox(height: 4),
                        Text(book.keyIndications!),
                      ],
                    ),
                  ),
                  const SizedBox(height: 15),
                ],
                Text('📖 বিস্তারিত বিবরণ:', style: TextStyle(fontWeight: FontWeight.bold, color: primaryDeepPine)),
                const SizedBox(height: 5),
                Text(book.fullDescription, style: TextStyle(color: textObsidian, fontSize: 15, height: 1.4)),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('বন্ধ করুন', style: TextStyle(color: primaryDeepPine, fontWeight: FontWeight.bold)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgAlabaster,
      appBar: AppBar(
        title: const Text('হোমিওপ্যাথিক জ্ঞানভাণ্ডার (Library)'),
        backgroundColor: primaryDeepPine,
        foregroundColor: bgAlabaster,
        bottom: _isSearching
            ? null
            : TabBar(
                controller: _tabController,
                labelColor: bgAlabaster,
                unselectedLabelColor: bgAlabaster.withOpacity(0.6),
                indicatorColor: bgAlabaster,
                tabs: const [
                  Tab(icon: Icon(Icons.healing_rounded), text: 'মেটেরিয়া মেডিকা'),
                  Tab(icon: Icon(Icons.accessibility_new_rounded), text: 'এনাটমি ও ফিজিওলজি'),
                ],
              ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: primaryDeepPine))
          : Column(
              children: [
                // লাইব্রেরি সার্চ বার
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: TextField(
                    controller: _searchController,
                    onChanged: _handleSearch,
                    style: TextStyle(color: textObsidian),
                    decoration: InputDecoration(
                      hintText: 'ঔষধের নাম, অঙ্গ বা লক্ষণ দিয়ে লাইব্রেরি খুঁজুন...',
                      prefixIcon: Icon(Icons.search, color: primaryDeepPine),
                      suffixIcon: _isSearching
                          ? IconButton(
                              icon: const Icon(Icons.clear),
                              onPressed: () {
                                _searchController.clear();
                                setState(() => _isSearching = false);
                              },
                            )
                          : null,
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                  ),
                ),
                
                // সার্চ বনাম ট্যাবের কন্ডিশনাল ভিউ
                Expanded(
                  child: _isSearching
                      ? _buildBookList(_searchResults, 'সার্চকৃত লক্ষণ বা ঔষধের কোনো মিল পাওয়া যায়নি।')
                      : TabBarView(
                          controller: _tabController,
                          children: [
                            _buildBookList(_materiaMedicaList, 'মেটেরিয়া মেডিকার কোনো তথ্য আপলোড করা নেই।'),
                            _buildBookList(_anatomyPhysiologyList, 'এনাটমি-ফিজিওলজি রেফারেন্স খালি।'),
                          ],
                        ),
                ),
              ],
            ),
    );
  }
}