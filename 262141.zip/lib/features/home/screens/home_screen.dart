import 'package:flutter/material.dart';
import '../../patient/screens/patient_list_screen.dart';
import '../../knowledge/screens/knowledge_library_screen.dart';
import '../../settings/screens/chamber_settings_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  // চোখের সুরক্ষার থিম কালারসমূহ (Warm Alabaster & Deep Pine)
  final Color bgAlabaster = const Color(0xFFF5F2EB); // পেপার ব্যাকগ্রাউন্ড
  final Color primaryDeepPine = const Color(0xFF1F3F3F); // ডার্ক পাইন গ্রিন
  final Color textObsidian = const Color(0xFF252B2B); // চারকোল টেক্সট

  // ড্যাশবোর্ডের গ্রিড বাটন তৈরির কমন মেথড
  Widget _buildDashboardCard({
    required BuildContext context,
    required String title,
    required IconData icon,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      color: Colors.white,
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: primaryDeepPine.withOpacity(0.1),
                child: Icon(icon, size: 35, color: primaryDeepPine),
              ),
              const SizedBox(height: 15),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: textObsidian),
              ),
              const SizedBox(height: 8),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: textObsidian.withOpacity(0.6)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // ট্যাবলেটের স্ক্রিন সাইজ অনুযায়ী কলাম সংখ্যা অ্যাডজাস্ট করা
    final double screenWidth = MediaQuery.of(context).size.width;
    final int crossAxisCount = screenWidth > 600 ? 3 : 2;

    return Scaffold(
      backgroundColor: bgAlabaster,
      appBar: AppBar(
        title: const Text('Pritha Homeo Record (ড্যাশবোর্ড)'),
        backgroundColor: primaryDeepPine,
        foregroundColor: bgAlabaster,
        elevation: 2,
        actions: [
          IconButton(
            icon: const Icon(Icons.verified_user_rounded),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ChamberSettingsScreen()),
              );
            },
          )
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // স্বাগতম ব্যানার ও চেম্বার স্লোগান
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: primaryDeepPine,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'স্বাগতম, ডাক্তার সাহেব!',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: bgAlabaster),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      'আপনার হোমিওপ্যাথিক অফলাইন কেস ম্যানেজমেন্ট রেকর্ড খাতা সম্পূর্ণ প্রস্তুত।',
                      style: TextStyle(fontSize: 14, color: bgAlabaster.withOpacity(0.8)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 25),
              
              Text(
                'প্রধান সেকশনসমূহ (Main Modules):',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: primaryDeepPine),
              ),
              const SizedBox(height: 15),

              // ড্যাশবোর্ড গ্রিড সিস্টেম (ডায়াগ্রাম অনুযায়ী ৩টি কোর সেকশন)
              Expanded(
                child: GridView.count(
                  crossAxisCount: crossAxisCount,
                  crossAxisSpacing: 15,
                  mainAxisSpacing: 15,
                  childAspectRatio: 0.95,
                  children: [
                    _buildDashboardCard(
                      context: context,
                      title: 'রোগী রেজিস্ট্রি ও তালিকা',
                      icon: Icons.people_alt_rounded,
                      subtitle: 'নতুন রোগী যোগ এবং কেস হিস্ট্রি খাতা',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const PatientListScreen()),
                        );
                      },
                    ),
                    _buildDashboardCard(
                      context: context,
                      title: 'জ্ঞানভাণ্ডার (Library)',
                      icon: Icons.local_library_rounded,
                      subtitle: 'মেটেরিয়া মেডিকা ও এনাটমি স্টাডি বুক',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const KnowledgeLibraryScreen()),
                        );
                      },
                    ),
                    _buildDashboardCard(
                      context: context,
                      title: 'চেম্বার সেটিংস',
                      icon: Icons.admin_panel_settings_rounded,
                      subtitle: 'ডাক্তারের নাম, চেম্বার লোগো ও মেটাডাটা',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const ChamberSettingsScreen()),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}