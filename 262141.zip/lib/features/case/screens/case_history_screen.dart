import 'package:flutter/material.dart';
import '../../../../core/database/case_db_service.dart';
import '../../../../core/models/case_master_model.dart';
import '../../../../core/models/acute_case_model.dart';
import '../../../../core/models/chronic_case_model.dart';
import '../../../../core/models/patient_model.dart';
import 'add_case_screen.dart';

class CaseHistoryScreen extends StatefulWidget {
  final PatientModel patient;

  const CaseHistoryScreen({super.key, required this.patient});

  @override
  State<CaseHistoryScreen> createState() => _CaseHistoryScreenState();
}

class _CaseHistoryScreenState extends State<CaseHistoryScreen> {
  final CaseDbService _caseDbService = CaseDbService();
  List<CaseMasterModel> _caseMasters = [];
  bool _isLoading = true;

  // চোখের সুরক্ষার থিম কালারসমূহ
  final Color bgAlabaster = const Color(0xFFF5F2EB);
  final Color primaryDeepPine = const Color(0xFF1F3F3F);
  final Color textObsidian = const Color(0xFF252B2B);

  @override
  void initState() {
    super.initState();
    _loadAllCases();
  }

  Future<void> _loadAllCases() async {
    setState(() => _isLoading = true);
    final data = await _caseDbService.getCasesByPatientId(widget.patient.patientId);
    setState(() {
      _caseMasters = data;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgAlabaster,
      appBar: AppBar(
        title: Text('${widget.patient.name} - এর রোগীলিপি খাতা'),
        backgroundColor: primaryDeepPine,
        foregroundColor: bgAlabaster,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator(color: primaryDeepPine))
          : _caseMasters.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.library_books_outlined, size: 70, color: primaryDeepPine.withOpacity(0.4)),
                      const SizedBox(height: 15),
                      Text(
                        'এই রোগীর কোনো পূর্বের রোগীলিপি রেকর্ড নেই।',
                        style: TextStyle(fontSize: 16, color: textObsidian.withOpacity(0.6), fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(10),
                  itemCount: _caseMasters.length,
                  itemBuilder: (context, index) {
                    final master = _caseMasters[index];
                    return _CaseDetailTile(
                      master: master,
                      caseDbService: _caseDbService,
                      primaryColor: primaryDeepPine,
                      textColor: textObsidian,
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AddCaseScreen(patientId: widget.patient.patientId),
            ),
          );
          if (result == true) {
            _loadAllCases();
          }
        },
        backgroundColor: primaryDeepPine,
        foregroundColor: bgAlabaster,
        icon: const Icon(Icons.add_to_photos_rounded),
        label: const Text('নতুন কেস টেকিং', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
    );
  }
}

// প্রতিটি কেসের বিস্তারিত ডাইনামিক লোড করার জন্য কাস্টম উইজেট
class _CaseDetailTile extends StatelessWidget {
  final CaseMasterModel master;
  final CaseDbService caseDbService;
  final Color primaryColor;
  final Color textColor;

  const _CaseDetailTile({
    required this.master,
    required this.caseDbService,
    required this.primaryColor,
    required this.textColor,
  });

  Widget _buildInfoRow(String title, String? value) {
    if (value == null || value.trim().isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(fontWeight: FontWeight.bold, color: primaryColor, fontSize: 14),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(color: textColor, fontSize: 15),
          ),
          const Divider(color: Colors.black12),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      margin: const EdgeInsets.symmetric(vertical: 8),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ExpansionTile(
        iconColor: primaryColor,
        collapsedIconColor: primaryColor.withOpacity(0.7),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: master.caseType == 'Acute' ? Colors.orange.shade100 : Colors.blue.shade100,
                borderRadius: BorderRadius.circular(5),
              ),
              child: Text(
                master.caseType == 'Acute' ? 'এক্যুট কেস' : 'ক্রনিক কেস',
                style: TextStyle(
                  color: master.caseType == 'Acute' ? Colors.orange.shade900 : Colors.blue.shade900,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'তারিখ: ${master.regDate.substring(0, 10)}',
                style: TextStyle(fontWeight: FontWeight.bold, color: textColor),
              ),
            ),
          ],
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4.0),
          child: Text('অবস্থা: ${master.status}', style: const TextStyle(fontSize: 13, color: Colors.grey)),
        ),
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: FutureBuilder(
              future: master.caseType == 'Acute'
                  ? caseDbService.getAcuteCaseDetails(master.caseId)
                  : caseDbService.getChronicCaseDetails(master.caseId),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (!snapshot.hasData || snapshot.data == null) {
                  return const Text('এই কেসের কোনো বিস্তারিত ডাটা পাওয়া যায়নি।');
                }

                if (master.caseType == 'Acute') {
                  final acute = snapshot.data as AcuteCaseModel;
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildInfoRow('📋 প্রধান কষ্ট ও তার বর্তমান বিস্তৃতি', acute.chiefComplaintAcute),
                      _buildInfoRow('⏳ রোগ আক্রমণের ধরণ ও সময়কাল', acute.onsetAndDuration),
                      _buildInfoRow('📍 রোগের স্থান ও গন্তব্য দিক', acute.locationAndDirection),
                      _buildInfoRow('⚡ অনুভূতির ধরণ ও ব্যথার ধরণ', acute.sensationAndPainType),
                      _buildInfoRow('📈 বৃদ্ধি কারক অবস্থা (Aggravations)', acute.modalitiesAggravation),
                      _buildInfoRow('📉 উপশম কারক অবস্থা (Ameliorations)', acute.modalitiesAmelioration),
                      _buildInfoRow('🔗 সহগামী লক্ষণসমূহ', acute.concomitantSymptoms),
                      _buildInfoRow('👅 এক্যুট শারীরিক লক্ষণ (জিহ্বা, তৃষ্ণা ইত্যাদি)', acute.physicalGeneralsAcute),
                      _buildInfoRow('🧠 রোগকালীন মানসিক অবস্থা ও মেজাজ', acute.mentalStateAcute),
                      if (acute.prescribedRemedy != null && acute.prescribedRemedy!.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(color: primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('💊 প্রদত্ত ঔষধ (এক্যুট)', style: TextStyle(fontWeight: FontWeight.bold, color: primaryColor, fontSize: 16)),
                              const SizedBox(height: 5),
                              Text('নাম: ${acute.prescribedRemedy}', style: const TextStyle(fontWeight: FontWeight.bold)),
                              Text('শক্তি: ${acute.remedyPotency ?? 'N/A'} | মাত্রা: ${acute.remedyDose ?? 'N/A'}'),
                            ],
                          ),
                        )
                      ]
                    ],
                  );
                } else {
                  final chronic = snapshot.data as ChronicCaseModel;
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildInfoRow('📋 বর্তমান রোগ লক্ষণাবলি (Presenting Illness)', chronic.presentingIllness),
                      _buildInfoRow('📈 রোগের সূত্রপাত এবং ক্রমবিকাশ', chronic.onsetAndProgress),
                      _buildInfoRow('🏥 রোগীর অতীত রোগসমূহ ও চিকিৎসার ইতিহাস', chronic.pastHistory),
                      _buildInfoRow('🌳 বংশগত বা পারিবারিক রোগ ইতিহাস', chronic.familyHistory),
                      _buildInfoRow('👤 ব্যক্তিগত ইতিহাস (টিকা, অভ্যাস)', chronic.personalHistory),
                      
                      const SizedBox(height: 5),
                      Text('🧬 শারীরিক সাধারণ লক্ষণসমূহ', style: TextStyle(fontWeight: FontWeight.bold, color: primaryColor, fontSize: 15)),
                      const Divider(thickness: 1.5),
                      
                      _buildInfoRow('🥶🥵 কাতরতা (Thermal Relation)', chronic.thermalRelation),
                      _buildInfoRow('💧 ক্ষুধা ও তৃষ্ণা', chronic.appetiteAndThirst),
                      _buildInfoRow('🍕 খাদ্য ইচ্ছা ও অনিচ্ছা', chronic.desiresAndAversions),
                      _buildInfoRow('🚽 ঘাম, প্রস্রাব ও মল প্রবণতা', chronic.sweatAndUrineStool),
                      _buildInfoRow('💤 ঘুম ও স্বপ্নের ধরণ', chronic.sleepAndDreams),
                      _buildInfoRow('👅 জিহ্বা ও শ্বাস-প্রশ্বাসের লক্ষণ', chronic.tongueAndBreath),
                      
                      const SizedBox(height: 5),
                      Text('🧠 মানসিক লক্ষণাবলি ও ধাতু', style: TextStyle(fontWeight: FontWeight.bold, color: primaryColor, fontSize: 15)),
                      const Divider(thickness: 1.5),
                      
                      _buildInfoRow('😡 মেজাজ, স্বভাব ও মানসিক লক্ষণ', chronic.mindAndDisposition),
                      _buildInfoRow('💡 বুদ্ধি ও স্মৃতিশক্তি', chronic.intellectAndMemory),
                      _buildInfoRow('😰 ভয় ও উদ্বেগসমূহ', chronic.fearsAndAnxieties),
                      _buildInfoRow('🔬 মায়াজম প্রাধান্য', chronic.miasmaticDominance),
                      _buildInfoRow('🦴 ধাতুগত ধরণ (Constitutional Type)', chronic.constitutionalType),
                      
                      if (chronic.selectedRemedyChronic != null && chronic.selectedRemedyChronic!.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(color: primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('💊 নির্বাচিত হোমিওপ্যাথিক ঔষধ ও নির্দেশনা', style: TextStyle(fontWeight: FontWeight.bold, color: primaryColor, fontSize: 16)),
                              const SizedBox(height: 5),
                              Text('ঔষধ: ${chronic.selectedRemedyChronic}', style: const TextStyle(fontWeight: FontWeight.bold)),
                              Text('শক্তি ও স্কেল: ${chronic.potencyScale ?? 'N/A'}'),
                              Text('সেবন বিধি ও পথ্য: ${chronic.remedyDosageInstructions ?? 'N/A'}'),
                            ],
                          ),
                        )
                      ]
                    ],
                  );
                }
              },
            ),
          )
        ],
      ),
    );
  }
}