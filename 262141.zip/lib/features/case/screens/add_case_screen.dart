import 'package:flutter/material.dart';
import '../../../../core/database/case_db_service.dart';
import '../../../../core/models/case_master_model.dart';
import '../../../../core/models/acute_case_model.dart';
import '../../../../core/models/chronic_case_model.dart';

class AddCaseScreen extends StatefulWidget {
  final String patientId;

  const AddCaseScreen({super.key, required this.patientId});

  @override
  State<AddCaseScreen> createState() => _AddCaseScreenState();
}

class _AddCaseScreenState extends State<AddCaseScreen> {
  final _formKey = GlobalKey<FormState>();
  final CaseDbService _caseDbService = CaseDbService();

  // থিম কালার ডিফাইন (চোখের সুরক্ষার জন্য)
  final Color bgAlabaster = const Color(0xFFF5F2EB); // পেপার কালার ব্যাকগ্রাউন্ড
  final Color primaryDeepPine = const Color(0xFF1F3F3F); // ডার্ক পাইন গ্রিন
  final Color textObsidian = const Color(0xFF252B2B); // চারকোল টেক্সট

  // কেস টাইপ স্টেট ('Acute' ডিফল্ট হিসেবে থাকবে)
  String _selectedCaseType = 'Acute';

  // --- এক্যুট কেসের জন্য কন্ট্রোলারসমূহ ---
  final _acuteComplaintController = TextEditingController();
  final _acuteOnsetController = TextEditingController();
  final _acuteLocationController = TextEditingController();
  final _acuteSensationController = TextEditingController();
  final _acuteAggravationController = TextEditingController();
  final _acuteAmeliorationController = TextEditingController();
  final _acuteConcomitantController = TextEditingController();
  final _acutePhysicalController = TextEditingController();
  final _acuteMentalController = TextEditingController();
  final _acuteRemedyController = TextEditingController();
  final _acutePotencyController = TextEditingController();
  final _acuteDoseController = TextEditingController();

  // --- ক্রনিক কেসের জন্য কন্ট্রোলারসমূহ ---
  final _chronicPresentingController = TextEditingController();
  final _chronicOnsetController = TextEditingController();
  final _chronicPastHistoryController = TextEditingController();
  final _chronicFamilyHistoryController = TextEditingController();
  final _chronicPersonalHistoryController = TextEditingController();
  final _chronicThermalController = TextEditingController();
  final _chronicAppetiteThirstController = TextEditingController();
  final _chronicDesiresAversionsController = TextEditingController();
  final _chronicSweatUrineController = TextEditingController();
  final _chronicSleepDreamsController = TextEditingController();
  final _chronicTongueBreathController = TextEditingController();
  final _chronicMindController = TextEditingController();
  final _chronicIntellectController = TextEditingController();
  final _chronicFearsController = TextEditingController();
  final _chronicMiasmController = TextEditingController();
  final _chronicConstitutionController = TextEditingController();
  final _chronicRemedyController = TextEditingController();
  final _chronicPotencyScaleController = TextEditingController();
  final _chronicDoseInstructionsController = TextEditingController();

  @override
  void dispose() {
    // সকল কন্ট্রোলার মেমোরি থেকে রিলিজ করা
    _acuteComplaintController.dispose(); _acuteOnsetController.dispose();
    _acuteLocationController.dispose(); _acuteSensationController.dispose();
    _acuteAggravationController.dispose(); _acuteAmeliorationController.dispose();
    _acuteConcomitantController.dispose(); _acutePhysicalController.dispose();
    _acuteMentalController.dispose(); _acuteRemedyController.dispose();
    _acutePotencyController.dispose(); _acuteDoseController.dispose();
    _chronicPresentingController.dispose(); _chronicOnsetController.dispose();
    _chronicPastHistoryController.dispose(); _chronicFamilyHistoryController.dispose();
    _chronicPersonalHistoryController.dispose(); _chronicThermalController.dispose();
    _chronicAppetiteThirstController.dispose(); _chronicDesiresAversionsController.dispose();
    _chronicSweatUrineController.dispose(); _chronicSleepDreamsController.dispose();
    _chronicTongueBreathController.dispose(); _chronicMindController.dispose();
    _chronicIntellectController.dispose(); _chronicFearsController.dispose();
    _chronicMiasmController.dispose(); _chronicConstitutionController.dispose();
    _chronicRemedyController.dispose(); _chronicPotencyScaleController.dispose();
    _chronicDoseInstructionsController.dispose();
    super.dispose();
  }

  void _saveDynamicCase() async {
    if (_formKey.currentState!.validate()) {
      final uniqueCaseId = DateTime.now().millisecondsSinceEpoch.toString();
      final currentTime = DateTime.now().toIso8601String();

      // ১. মাস্টার কেস ডাটা তৈরি
      final masterCase = CaseMasterModel(
        caseId: uniqueCaseId,
        patientId_fk: widget.patientId,
        caseType: _selectedCaseType,
        regDate: currentTime,
        status: 'Active',
        createdAt: currentTime,
      );

      await _caseDbService.insertCaseMaster(masterCase);

      // ২. সিলেকশন অনুযায়ী নির্দিষ্ট টেবিলে হোমিওপ্যাথিক ডাটা সেভ
      if (_selectedCaseType == 'Acute') {
        final acuteCase = AcuteCaseModel(
          caseIdFk: uniqueCaseId,
          chiefComplaintAcute: _acuteComplaintController.text.trim(),
          onsetAndDuration: _acuteOnsetController.text.trim(),
          locationAndDirection: _acuteLocationController.text.trim(),
          sensationAndPainType: _acuteSensationController.text.trim(),
          modalitiesAggravation: _acuteAggravationController.text.trim(),
          modalitiesAmelioration: _acuteAmeliorationController.text.trim(),
          concomitantSymptoms: _acuteConcomitantController.text.trim(),
          physicalGeneralsAcute: _acutePhysicalController.text.trim(),
          mentalStateAcute: _acuteMentalController.text.trim(),
          prescribedRemedy: _acuteRemedyController.text.trim(),
          remedyPotency: _acutePotencyController.text.trim(),
          remedyDose: _acuteDoseController.text.trim(),
        );
        await _caseDbService.insertAcuteCase(acuteCase);
      } else {
        final chronicCase = ChronicCaseModel(
          caseIdFk: uniqueCaseId,
          presentingIllness: _chronicPresentingController.text.trim(),
          onsetAndProgress: _chronicOnsetController.text.trim(),
          pastHistory: _chronicPastHistoryController.text.trim(),
          familyHistory: _chronicFamilyHistoryController.text.trim(),
          personalHistory: _chronicPersonalHistoryController.text.trim(),
          thermalRelation: _chronicThermalController.text.trim(),
          appetiteAndThirst: _chronicAppetiteThirstController.text.trim(),
          desiresAndAversions: _chronicDesiresAversionsController.text.trim(),
          sweatAndUrineStool: _chronicSweatUrineController.text.trim(),
          sleepAndDreams: _chronicSleepDreamsController.text.trim(),
          tongueAndBreath: _chronicTongueBreathController.text.trim(),
          mindAndDisposition: _chronicMindController.text.trim(),
          intellectAndMemory: _chronicIntellectController.text.trim(),
          fearsAndAnxieties: _chronicFearsController.text.trim(),
          miasmaticDominance: _chronicMiasmController.text.trim(),
          constitutionalType: _chronicConstitutionController.text.trim(),
          selectedRemedyChronic: _chronicRemedyController.text.trim(),
          potencyScale: _chronicPotencyScaleController.text.trim(),
          remedyDosageInstructions: _chronicDoseInstructionsController.text.trim(),
        );
        await _caseDbService.insertChronicCase(chronicCase);
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('রোগীলিপি সফলভাবে সংরক্ষিত হয়েছে।')),
        );
        Navigator.pop(context, true);
      }
    }
  }

  // টেক্সট ফিল্ডের জন্য কমন ডিজাইন মেথড (কোড ছোট রাখার জন্য)
  Widget _buildTextField({
    required TextEditingController controller,
    required String labelText,
    int maxLines = 2,
    bool isRequired = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: TextFormField(
        controller: controller,
        maxLines: maxLines,
        style: TextStyle(color: textObsidian),
        decoration: InputDecoration(
          labelText: labelText + (isRequired ? ' *' : ''),
          labelStyle: TextStyle(color: primaryDeepPine.withOpacity(0.8)),
          alignLabelWithHint: true,
          filled: true,
          fillColor: Colors.white,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: primaryDeepPine.withOpacity(0.3)),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: primaryDeepPine, width: 2),
          ),
          border: const OutlineInputBorder(),
        ),
        validator: isRequired
            ? (value) {
                if (value == null || value.trim().isEmpty) {
                  return '$labelText পূরণ করা আবশ্যক';
                }
                return null;
              }
            : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgAlabaster,
      appBar: AppBar(
        title: const Text('ডাইনামিক কেস টেকিং শিট'),
        backgroundColor: primaryDeepPine,
        foregroundColor: bgAlabaster,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ১. কেস টাইপ নির্বাচনের ড্রপডাউন (ডাইনামিক ফ্লো সুইচ)
              Card(
                color: Colors.white,
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'রোগের ধরন (Disease Classification):',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: primaryDeepPine),
                      ),
                      DropdownButton<String>(
                        value: _selectedCaseType,
                        dropdownColor: Colors.white,
                        style: TextStyle(color: primaryDeepPine, fontWeight: FontWeight.bold, fontSize: 16),
                        items: const [
                          DropdownMenuItem(value: 'Acute', child: Text('Acute (এক্যুট / নতুন রোগ)')),
                          DropdownMenuItem(value: 'Chronic', child: Text('Chronic (ক্রনিক / জটিল রোগ)')),
                        ],
                        onChanged: (value) {
                          if (value != null) {
                            setState(() {
                              _selectedCaseType = value;
                            });
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // ২. কন্ডিশনাল হোমিওপ্যাথিক ফর্ম সেকশন
              if (_selectedCaseType == 'Acute') ...[
                // --- ACUTE WORKFLOW FORM ---
                Text('【 Acute Mode - এক্যুট লক্ষণাবলি 】', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: primaryDeepPine)),
                const SizedBox(height: 15),
                _buildTextField(controller: _acuteComplaintController, labelText: 'প্রধান কষ্ট ও তার বর্তমান বিস্তৃতি', maxLines: 3, isRequired: true),
                _buildTextField(controller: _acuteOnsetController, labelText: 'রোগ আক্রমণের ধরণ ও সময়কাল (Onset & Duration)'),
                _buildTextField(controller: _acuteLocationController, labelText: 'রোগের স্থান ও গন্তব্য দিক (Location & Direction)'),
                _buildTextField(controller: _acuteSensationController, labelText: 'অনুভূতির ধরণ ও ব্যথার ধরণ (Sensation & Pain Type)'),
                _buildTextField(controller: _acuteAggravationController, labelText: 'বৃদ্ধি কারক অবস্থা (Aggravations)'),
                _buildTextField(controller: _acuteAmeliorationController, labelText: 'উপশম কারক অবস্থা (Ameliorations)'),
                _buildTextField(controller: _acuteConcomitantController, labelText: 'সহগামী লক্ষণসমূহ (Concomitant Symptoms)'),
                _buildTextField(controller: _acutePhysicalController, labelText: 'এক্যুট শারীরিক লক্ষণ (জিহ্বা, তৃষ্ণা, ক্ষুধা, মল-মূত্র)'),
                _buildTextField(controller: _acuteMentalController, labelText: 'রোগকালীন মানসিক অবস্থা ও মেজাজ'),
                const Divider(height: 40, thickness: 2),
                Text('💊 প্রেসক্রিপশন (এক্যুট)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: primaryDeepPine)),
                const SizedBox(height: 15),
                _buildTextField(controller: _acuteRemedyController, labelText: 'নির্বাচিত ঔষধের নাম'),
                Row(
                  children: [
                    Expanded(child: _buildTextField(controller: _acutePotencyController, labelText: 'শক্তি (Potency)')),
                    const SizedBox(width: 10),
                    Expanded(child: _buildTextField(controller: _acuteDoseController, labelText: 'মাত্রা ও প্রয়োগ বিধি')),
                  ],
                ),
              ] else ...[
                // --- CHRONIC WORKFLOW FORM ---
                Text('【 Chronic Mode - ক্রনিক রোগীলিপি শিরোনামসমূহ 】', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: primaryDeepPine)),
                const SizedBox(height: 15),
                _buildTextField(controller: _chronicPresentingController, labelText: 'বর্তমান রোগ লক্ষণাবলি (Presenting Illness)', maxLines: 4, isRequired: true),
                _buildTextField(controller: _chronicOnsetController, labelText: 'রোগের সূত্রপাত এবং ক্রমবিকাশ'),
                _buildTextField(controller: _chronicPastHistoryController, labelText: 'রোগীর অতীত রোগসমূহ ও চিকিৎসার ইতিহাস (Past Illnesses)', maxLines: 3),
                _buildTextField(controller: _chronicFamilyHistoryController, labelText: 'বংশগত বা পারিবারিক রোগ ইতিহাস (Family History)', maxLines: 3),
                _buildTextField(controller: _chronicPersonalHistoryController, labelText: 'ব্যক্তিগত ইতিহাস (টিকা দান, অভ্যাস, জীবনযাত্রা)'),
                
                const SizedBox(height: 10),
                Text('🧬 শারীরিক সাধারণ লক্ষণসমূহ (Physical Generals)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: primaryDeepPine)),
                const SizedBox(height: 10),
                _buildTextField(controller: _chronicThermalController, labelText: 'কাতরতা (Thermal Relation - Chilly/Hot/Ambithermal)'),
                _buildTextField(controller: _chronicAppetiteThirstController, labelText: 'ক্ষুধা ও তৃষ্ণা'),
                _buildTextField(controller: _chronicDesiresAversionsController, labelText: 'খাদ্য ইচ্ছা ও অনিচ্ছা (Desires & Aversions)'),
                _buildTextField(controller: _chronicSweatUrineController, labelText: 'ঘাম, প্রস্রাব ও মল প্রবণতা'),
                _buildTextField(controller: _chronicSleepDreamsController, labelText: 'ঘুম ও স্বপ্নের ধরণ'),
                _buildTextField(controller: _chronicTongueBreathController, labelText: 'জিহ্বা ও শ্বাস-প্রশ্বাসের লক্ষণ'),
                
                const SizedBox(height: 10),
                Text('🧠 মানসিক লক্ষণাবলি ও ধাতু (Mental Generals & Constitution)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: primaryDeepPine)),
                const SizedBox(height: 10),
                _buildTextField(controller: _chronicMindController, labelText: 'মেজাজ, स्वभाव ও মানসিক লক্ষণ', maxLines: 3),
                _buildTextField(controller: _chronicIntellectController, labelText: 'বুদ্ধি ও স্মৃতিশক্তি'),
                _buildTextField(controller: _chronicFearsController, labelText: 'ভয় ও উদ্বেগসমূহ'),
                _buildTextField(controller: _chronicMiasmController, labelText: 'মায়াজম প্রাধান্য (Psora / Sycosis / Syphilis / Tubercular)'),
                _buildTextField(controller: _chronicConstitutionController, labelText: 'ধাতুগত ধরণ (Constitutional Type/Diathesis)'),
                
                const Divider(height: 40, thickness: 2),
                Text('💊 নির্বাচিত ঔষধ ও নির্দেশনা (ক্রনিক)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: primaryDeepPine)),
                const SizedBox(height: 15),
                _buildTextField(controller: _chronicRemedyController, labelText: 'নির্বাচিত ঔষধ'),
                _buildTextField(controller: _chronicPotencyScaleController, labelText: 'শক্তি ও স্কেল (যেমন: Centesimal / 50 Millesimal)'),
                _buildTextField(controller: _chronicDoseInstructionsController, labelText: 'সেবন বিধি ও পথ্য', maxLines: 3),
              ],

              const SizedBox(height: 25),

              // ৩. সংরক্ষণ বাটন
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton.icon(
                  onPressed: _saveDynamicCase,
                  icon: const Icon(Icons.assignment_turned_in_rounded),
                  label: const Text('সম্পূর্ণ কেসটি সংরক্ষণ করুন', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryDeepPine,
                    foregroundColor: bgAlabaster,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}