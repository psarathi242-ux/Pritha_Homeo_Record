import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';
import '../models/case_master_model.dart';
import '../models/acute_case_model.dart';
import '../models/chronic_case_model.dart';

class CaseDbService {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  // ১. নতুন কেস মাস্টার (মেইন রোগীলিপি রেকর্ড) তৈরি করা
  Future<int> insertCaseMaster(CaseMasterModel caseModel) async {
    final db = await _dbHelper.database;
    return await db.insert(
      'CASE_MASTER',
      caseModel.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ২. এক্যুট কেসের বিস্তারিত তথ্য সেভ করা (Insert Acute Case)
  Future<int> insertAcuteCase(AcuteCaseModel acuteModel) async {
    final db = await _dbHelper.database;
    return await db.insert(
      'ACUTE_CASE_DETAILS',
      acuteModel.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ৩. ক্রনিক কেসের বিস্তারিত তথ্য সেভ করা (Insert Chronic Case)
  Future<int> insertChronicCase(ChronicCaseModel chronicModel) async {
    final db = await _dbHelper.database;
    return await db.insert(
      'CHRONIC_CASE_DETAILS',
      chronicModel.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ৪. নির্দিষ্ট রোগীর সমস্ত কেস মাস্টারের তালিকা দেখা
  Future<List<CaseMasterModel>> getCasesByPatientId(String patientId) async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'CASE_MASTER',
      where: 'patient_id_fk = ?',
      whereArgs: [patientId],
      orderBy: 'reg_date DESC',
    );

    return List.generate(maps.length, (i) {
      return CaseMasterModel.fromMap(maps[i]);
    });
  }

  // ৫. একক এক্যুট কেসের লক্ষণাদি রিটার্ন করা
  Future<AcuteCaseModel?> getAcuteCaseDetails(String caseId) async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'ACUTE_CASE_DETAILS',
      where: 'case_id_fk = ?',
      whereArgs: [caseId],
    );

    if (maps.isEmpty) return null;
    return AcuteCaseModel.fromMap(maps.first);
  }

  // ৬. একক ক্রনিক কেসের লক্ষণাদি রিটার্ন করা
  Future<ChronicCaseModel?> getChronicCaseDetails(String caseId) async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'CHRONIC_CASE_DETAILS',
      where: 'case_id_fk = ?',
      whereArgs: [caseId],
    );

    if (maps.isEmpty) return null;
    return ChronicCaseModel.fromMap(maps.first);
  }

  // ৭. কেস মাস্টার ডিলিট করা (Cascade-এর কারণে এর সাথে সম্পর্কিত ডিটেইলসও ডিলিট হবে)
  Future<int> deleteCase(String caseId) async {
    final db = await _dbHelper.database;
    return await db.delete(
      'CASE_MASTER',
      where: 'case_id = ?',
      whereArgs: [caseId],
    );
  }
}