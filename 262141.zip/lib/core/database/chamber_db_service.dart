import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';
import '../models/chamber_settings_model.dart';

class ChamberDbService {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  // চেম্বার সেটিংস সেভ বা আপডেট করা
  Future<int> saveChamberSettings(ChamberSettingsModel settings) async {
    final db = await _dbHelper.database;
    
    // যেহেতু চেম্বার সেটিংস কেবল ১টি রো (Row) ধারণ করবে, তাই আগের ডাটা মুছে বা রিপ্লেস করে সেভ হবে
    final List<Map<String, dynamic>> existing = await db.query('CHAMBER_SETTINGS');
    
    if (existing.isEmpty) {
      return await db.insert(
        'CHAMBER_SETTINGS',
        settings.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } else {
      final id = existing.first['id'];
      return await db.update(
        'CHAMBER_SETTINGS',
        settings.toMap(),
        where: 'id = ?',
        whereArgs: [id],
      );
    }
  }

  // ডাটাবেস থেকে চেম্বার প্রোফাইল রিড করা
  Future<ChamberSettingsModel?> getChamberSettings() async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query('CHAMBER_SETTINGS');

    if (maps.isEmpty) return null;
    return ChamberSettingsModel.fromMap(maps.first);
  }
}