import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';
import '../models/knowledge_model.dart';

class KnowledgeDbService {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  // ১. জ্ঞানভাণ্ডারে নতুন কোনো চ্যাপ্টার বা ঔষধের ডাটা যুক্ত করা (অফলাইন ইম্পোর্ট)
  Future<int> insertKnowledge(KnowledgeModel knowledge) async {
    final db = await _dbHelper.database;
    return await db.insert(
      'KNOWLEDGE_LIBRARY',
      knowledge.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ২. সেকশন অনুযায়ী (যেমন: শুধু 'Materia Medica' এর) সকল বই/ঔষধের তালিকা আনা
  Future<List<KnowledgeModel>> getKnowledgeBySection(String sectionType) async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'KNOWLEDGE_LIBRARY',
      where: 'section_type = ?',
      whereArgs: [sectionType],
      orderBy: 'subject_title ASC',
    );

    return List.generate(maps.length, (i) => KnowledgeModel.fromMap(maps[i]));
  }

  // ৩. লাইব্রেরিতে কোনো নির্দিষ্ট ঔষধ বা লক্ষণের নাম দিয়ে সার্চ করা (খুবই গুরুত্বপূর্ণ)
  Future<List<KnowledgeModel>> searchKnowledge(String query) async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'KNOWLEDGE_LIBRARY',
      where: 'subject_title LIKE ? OR key_indications LIKE ? OR full_description LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
      orderBy: 'subject_title ASC',
    );

    return List.generate(maps.length, (i) => KnowledgeModel.fromMap(maps[i]));
  }
}