import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';
import '../models/patient_model.dart';

class PatientDbService {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  // ১. নতুন রোগী যোগ করা (Insert Patient)
  Future<int> insertPatient(PatientModel patient) async {
    final db = await _dbHelper.database;
    return await db.insert(
      'PATIENT',
      patient.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace, // যদি একই আইডি থাকে তবে আপডেট করবে
    );
  }

  // ২. সকল রোগীর তালিকা দেখা (Get All Patients)
  Future<List<PatientModel>> getAllPatients() async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query('PATIENT', orderBy: 'created_at DESC');

    return List.generate(maps.length, (i) {
      return PatientModel.fromMap(maps[i]);
    });
  }

  // ৩. আইডি দিয়ে নির্দিষ্ট কোনো রোগীকে খোঁজা (Get Patient by ID)
  Future<PatientModel?> getPatientById(String id) async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'PATIENT',
      where: 'patient_id = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return PatientModel.fromMap(maps.first);
    }
    return null;
  }

  // ৪. রোগীর নাম বা ফোন নাম্বার দিয়ে সার্চ করা (Search Patients)
  Future<List<PatientModel>> searchPatients(String query) async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'PATIENT',
      where: 'name LIKE ? OR phone LIKE ?',
      whereArgs: ['%$query%', '%$query%'],
      orderBy: 'name ASC',
    );

    return List.generate(maps.length, (i) {
      return PatientModel.fromMap(maps[i]);
    });
  }

  // ৫. রোগীর তথ্য এডিট বা সংশোধন করা (Update Patient)
  Future<int> updatePatient(PatientModel patient) async {
    final db = await _dbHelper.database;
    return await db.update(
      'PATIENT',
      patient.toMap(),
      where: 'patient_id = ?',
      whereArgs: [patient.patientId],
    );
  }

  // ৬. রোগী ডিলিট করা (Delete Patient)
  Future<int> deletePatient(String id) async {
    final db = await _dbHelper.database;
    return await db.delete(
      'PATIENT',
      where: 'patient_id = ?',
      whereArgs: [id],
    );
  }
}