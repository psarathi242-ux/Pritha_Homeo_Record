import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static const _databaseName = "PrithaHomeoRecord_v3.db";
  static const _databaseVersion = 1;

  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;
  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  _initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, _databaseName);
    return await openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _onCreate,
    );
  }

  Future _onCreate(Database db, int version) async {
    
    // ১. চেম্বার প্রোফাইল ও ব্র্যান্ডিং টেবিল (Chamber Details & Logo Path)
    await db.execute('''
      CREATE TABLE CHAMBER_SETTINGS (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        doctor_name TEXT NOT NULL,
        degrees TEXT,
        chamber_name TEXT NOT NULL,
        address TEXT,
        phone TEXT,
        email TEXT,
        logo_path TEXT, -- গ্যালারি থেকে সিলেক্ট করা লোগোর পাথ
        prescription_footer TEXT
      )
    ''');

    // ২. পেশেন্ট ডেটা টেবিল (Patient Core Profile)
    await db.execute('''
      CREATE TABLE PATIENT (
        patient_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        gender TEXT NOT NULL,
        age_years INTEGER,
        age_months INTEGER, -- শিশু রোগীদের জন্য গুরুত্বপূর্ণ
        phone TEXT,
        occupation TEXT,
        address TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    // ৩. কেস মাস্টার টেবিল (Workflow Route - Acute/Chronic)
    await db.execute('''
      CREATE TABLE CASE_MASTER (
        case_id TEXT PRIMARY KEY,
        patient_id_fk TEXT NOT NULL,
        case_type TEXT NOT NULL, -- 'Acute' (এক্যুট) অথবা 'Chronic' (ক্রনিক)
        reg_date TEXT NOT NULL,
        status TEXT NOT NULL, -- 'Active', 'Improved', 'Cured', 'Closed'
        created_at TEXT NOT NULL,
        FOREIGN KEY (patient_id_fk) REFERENCES PATIENT (patient_id) ON DELETE CASCADE
      )
    ''');

    // ৪. এক্যুট রোগীলিপি টেবিল (Acute Case Taking - ডায়াগ্রামের প্রতিটি শিরোনাম সহ)
    await db.execute('''
      CREATE TABLE ACUTE_CASE_DETAILS (
        case_id_fk TEXT PRIMARY KEY,
        chief_complaint_acute TEXT NOT NULL, -- প্রধান কষ্ট ও তার বর্তমান বিস্তৃতি
        onset_and_duration TEXT, -- রোগ আক্রমণের ধরণ ও সময়কাল
        location_and_direction TEXT, -- রোগের স্থান ও গন্তব্য দিক (Location & Direction)
        sensation_and_pain_type TEXT, -- অনুভূতির ধরণ ও ব্যথার ধরণ (Sensation & Pain Type)
        modalities_aggravation TEXT, -- বৃদ্ধি কারক অবস্থা (Aggravations)
        modalities_amelioration TEXT, -- উপশম কারক অবস্থা (Ameliorations)
        concomitant_symptoms TEXT, -- সহগামী লক্ষণসমূহ (Concomitant Symptoms)
        physical_generals_acute TEXT, -- এক্যুট শারীরিক লক্ষণ (জিহ্বা, তৃষ্ণা, ক্ষুধা, মল-মূত্র)
        mental_state_acute TEXT, -- রোগকালীন মানসিক অবস্থা ও মেজাজ
        prescribed_remedy TEXT, -- নির্বাচিত ঔষধের নাম
        remedy_potency TEXT, -- ঔষধের শক্তি (Potency)
        remedy_dose TEXT, -- মাত্রা ও প্রয়োগ বিধি (Dose & Instructions)
        FOREIGN KEY (case_id_fk) REFERENCES CASE_MASTER (case_id) ON DELETE CASCADE
      )
    ''');

    // ৫. ক্রনিক রোগীলিপি টেবিল (Chronic Case Taking - হোমিওপ্যাথিক শিরোনাম অনুযায়ী)
    await db.execute('''
      CREATE TABLE CHRONIC_CASE_DETAILS (
        case_id_fk TEXT PRIMARY KEY,
        presenting_illness TEXT NOT NULL, -- বর্তমান রোগ লক্ষণাবলি (Presenting Illness)
        onset_and_progress TEXT, -- রোগের সূত্রপাত এবং ক্রমবিকাশ
        past_history TEXT, -- রোগীর অতীত রোগসমূহ ও চিকিৎসার ইতিহাস (Past Illnesses)
        family_history TEXT, -- বংশগত বা পারিবারিক রোগ ইতিহাস (Family History)
        personal_history TEXT, -- ব্যক্তিগত ইতিহাস (টিকা দান, অভ্যাস, জীবনযাত্রা)
        
        -- শারীরিক সাধারণ লক্ষণসমূহ (Physical Generals)
        thermal_relation TEXT, -- কাতরতা (Chilly/Hot/Ambithermal)
        appetite_and_thirst TEXT, -- ক্ষুধা ও তৃষ্ণা
        desires_and_aversions TEXT, -- খাদ্য ইচ্ছা ও অনিচ্ছা (Desires & Aversions)
        sweat_and_urine_stool TEXT, -- ঘাম, প্রস্রাব ও মল প্রবণতা
        sleep_and_dreams TEXT, -- ঘুম ও স্বপ্নের ধরণ
        tongue_and_breath TEXT, -- জিহ্বা ও শ্বাস-প্রশ্বাসের লক্ষণ
        
        -- মানসিক লক্ষণাবলি (Mental Generals & Constitution)
        mind_and_disposition TEXT, -- মেজাজ, স্বভাব ও মানসিক লক্ষণ
        intellect_and_memory TEXT, -- বুদ্ধি ও স্মৃতিশক্তি
        fears_and_anxieties TEXT, -- ভয় ও উদ্বেগসমূহ
        
        -- মায়াজমেটিক ও ধাতুগত বিশ্লেষণ (Miasmatic & Constitutional)
        miasmatic_dominance TEXT, -- মায়াজম প্রাধান্য (Psora / Sycosis / Syphilis / Tubercular)
        constitutional_type TEXT, -- ধাতুগত ধরণ (Constitutional Type/Diathesis)
        
        -- প্রেসক্রিপশন ও নির্দেশনা
        selected_remedy_chronic TEXT, -- নির্বাচিত ঔষধ
        potency_scale TEXT, -- শক্তি ও স্কেল (যেমন: Centesimal / 50 Millesimal)
        remedy_dosage_instructions TEXT, -- সেবন বিধি ও পথ্য
        FOREIGN KEY (case_id_fk) REFERENCES CASE_MASTER (case_id) ON DELETE CASCADE
      )
    ''');

    // ৬. জ্ঞানভাণ্ডার লাইব্রেরি টেবিল (Knowledge Library - বিখ্যাত লেখকদের ডেটাবেস)
    await db.execute('''
      CREATE TABLE KNOWLEDGE_LIBRARY (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        section_type TEXT NOT NULL, -- 'Materia Medica' (মেটেরিয়া মেডিকা) বা 'Anatomy_Physiology' (এনাটমি)
        subject_title TEXT NOT NULL, -- ঔষধের নাম বা অধ্যায়ের নাম (যেমন: 'Arsenicum Album' বা 'Cardiovascular System')
        author_or_source TEXT, -- লেখকের নাম (যেমন: 'J.T. Kent', 'William Boericke', 'H.C. Allen')
        key_indications TEXT, -- ঔষধের প্রধান নির্দেশক লক্ষণসমূহ (Keynotes)
        full_description TEXT NOT NULL -- বিস্তারিত বর্ণনা
      )
    ''');
  }
}