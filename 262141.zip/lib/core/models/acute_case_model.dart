class AcuteCaseModel {
  final String caseIdFk;
  final String chiefComplaintAcute;
  final String? onsetAndDuration;
  final String? locationAndDirection;
  final String? sensationAndPainType;
  final String? modalitiesAggravation;
  final String? modalitiesAmelioration;
  final String? concomitantSymptoms;
  final String? physicalGeneralsAcute;
  final String? mentalStateAcute;
  final String? prescribedRemedy;
  final String? remedyPotency;
  final String? remedyDose;

  AcuteCaseModel({
    required this.caseIdFk,
    required this.chiefComplaintAcute,
    this.onsetAndDuration,
    this.locationAndDirection,
    this.sensationAndPainType,
    this.modalitiesAggravation,
    this.modalitiesAmelioration,
    this.concomitantSymptoms,
    this.physicalGeneralsAcute,
    this.mentalStateAcute,
    this.prescribedRemedy,
    this.remedyPotency,
    this.remedyDose,
  });

  factory AcuteCaseModel.fromMap(Map<String, dynamic> map) {
    return AcuteCaseModel(
      caseIdFk: map['case_id_fk'] as String,
      chiefComplaintAcute: map['chief_complaint_acute'] as String,
      onsetAndDuration: map['onset_and_duration'] as String?,
      locationAndDirection: map['location_and_direction'] as String?,
      sensationAndPainType: map['sensation_and_pain_type'] as String?,
      modalitiesAggravation: map['modalities_aggravation'] as String?,
      modalitiesAmelioration: map['modalities_amelioration'] as String?,
      concomitantSymptoms: map['concomitant_symptoms'] as String?,
      physicalGeneralsAcute: map['physical_generals_acute'] as String?,
      mentalStateAcute: map['mental_state_acute'] as String?,
      prescribedRemedy: map['prescribed_remedy'] as String?,
      remedyPotency: map['remedy_potency'] as String?,
      remedyDose: map['remedy_dose'] as String?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'case_id_fk': caseIdFk,
      'chief_complaint_acute': chiefComplaintAcute,
      'onset_and_duration': onsetAndDuration,
      'location_and_direction': locationAndDirection,
      'sensation_and_pain_type': sensationAndPainType,
      'modalities_aggravation': modalitiesAggravation,
      'modalities_amelioration': modalitiesAmelioration,
      'concomitant_symptoms': concomitantSymptoms,
      'physical_generals_acute': physicalGeneralsAcute,
      'mental_state_acute': mentalStateAcute,
      'prescribed_remedy': prescribedRemedy,
      'remedy_potency': remedyPotency,
      'remedy_dose': remedyDose,
    };
  }
}