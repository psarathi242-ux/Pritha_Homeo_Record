class PatientModel {
  final String patientId;
  final String name;
  final String gender;
  final int? ageYears;
  final int? ageMonths; // শিশু রোগীদের সঠিক বয়স হিসাবের জন্য
  final String? phone;
  final String? occupation;
  final String? address;
  final String createdAt;

  PatientModel({
    required this.patientId,
    required this.name,
    required this.gender,
    this.ageYears,
    this.ageMonths,
    this.phone,
    this.occupation,
    this.address,
    required this.createdAt,
  });

  // Map থেকে অবজেক্টে রূপান্তর (ডেটাবেস থেকে রিড করার সময়)
  factory PatientModel.fromMap(Map<String, dynamic> map) {
    return PatientModel(
      patientId: map['patient_id'] as String,
      name: map['name'] as String,
      gender: map['gender'] as String,
      ageYears: map['age_years'] as int?,
      ageMonths: map['age_months'] as int?,
      phone: map['phone'] as String?,
      occupation: map['occupation'] as String?,
      address: map['address'] as String?,
      createdAt: map['created_at'] as String,
    );
  }

  // অবজেক্ট থেকে Map-এ রূপান্তর (ডেটাবেসে সেভ করার সময়)
  Map<String, dynamic> toMap() {
    return {
      'patient_id': patientId,
      'name': name,
      'gender': gender,
      'age_years': ageYears,
      'age_months': ageMonths,
      'phone': phone,
      'occupation': occupation,
      'address': address,
      'created_at': createdAt,
    };
  }
}