class KnowledgeModel {
  final int? id;
  final String sectionType; // 'Materia Medica' অথবা 'Anatomy_Physiology'
  final String subjectTitle; // ঔষধের নাম (যেমন: Pulsatilla) বা সিস্টেমের নাম
  final String? authorOrSource; // যেমন: J.T. Kent, Boericke, Allen
  final String? keyIndications; // ঔষধের মূল কি-নোটস বা রেড-লাইন লক্ষণসমূহ
  final String fullDescription; // বিস্তারিত মূল টেক্সট বা অধ্যায়ের বর্ণনা

  KnowledgeModel({
    this.id,
    required this.sectionType,
    required this.subjectTitle,
    this.authorOrSource,
    this.keyIndications,
    required this.fullDescription,
  });

  factory KnowledgeModel.fromMap(Map<String, dynamic> map) {
    return KnowledgeModel(
      id: map['id'] as int?,
      sectionType: map['section_type'] as String,
      subjectTitle: map['subject_title'] as String,
      authorOrSource: map['author_or_source'] as String?,
      keyIndications: map['key_indications'] as String?,
      fullDescription: map['full_description'] as String,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'section_type': sectionType,
      'subject_title': subjectTitle,
      'author_or_source': authorOrSource,
      'key_indications': keyIndications,
      'full_description': fullDescription,
    };
  }
}