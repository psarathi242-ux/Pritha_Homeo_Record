class CaseMasterModel {
  final String caseId;
  final String patientId_fk;
  final String caseType; // 'Acute' অথবা 'Chronic'
  final String regDate;
  final String status; // 'Active', 'Improved', 'Cured', 'Closed'
  final String createdAt;

  CaseMasterModel({
    required this.caseId,
    required this.patientId_fk,
    required this.caseType,
    required this.regDate,
    required this.status,
    required this.createdAt,
  });

  factory CaseMasterModel.fromMap(Map<String, dynamic> map) {
    return CaseMasterModel(
      caseId: map['case_id'] as String,
      patientId_fk: map['patient_id_fk'] as String,
      caseType: map['case_type'] as String,
      regDate: map['reg_date'] as String,
      status: map['status'] as String,
      createdAt: map['created_at'] as String,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'case_id': caseId,
      'patient_id_fk': patientId_fk,
      'case_type': caseType,
      'reg_date': regDate,
      'status': status,
      'created_at': createdAt,
    };
  }
}