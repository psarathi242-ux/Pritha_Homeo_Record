class ChronicCaseModel {
  final String caseIdFk;
  final String presentingIllness;
  final String? onsetAndProgress;
  final String? pastHistory;
  final String? familyHistory;
  final String? personalHistory;
  final String? thermalRelation;
  final String? appetiteAndThirst;
  final String? desiresAndAversions;
  final String? sweatAndUrineStool;
  final String? sleepAndDreams;
  final String? tongueAndBreath;
  final String? mindAndDisposition;
  final String? intellectAndMemory;
  final String? fearsAndAnxieties;
  final String? miasmaticDominance;
  final String? constitutionalType;
  final String? selectedRemedyChronic;
  final String? potencyScale;
  final String? remedyDosageInstructions;

  ChronicCaseModel({
    required this.caseIdFk,
    required this.presentingIllness,
    this.onsetAndProgress,
    this.pastHistory,
    this.familyHistory,
    this.personalHistory,
    this.thermalRelation,
    this.appetiteAndThirst,
    this.desiresAndAversions,
    this.sweatAndUrineStool,
    this.sleepAndDreams,
    this.tongueAndBreath,
    this.mindAndDisposition,
    this.intellectAndMemory,
    this.fearsAndAnxieties,
    this.miasmaticDominance,
    this.constitutionalType,
    this.selectedRemedyChronic,
    this.potencyScale,
    this.remedyDosageInstructions,
  });

  factory ChronicCaseModel.fromMap(Map<String, dynamic> map) {
    return ChronicCaseModel(
      caseIdFk: map['case_id_fk'] as String,
      presentingIllness: map['presenting_illness'] as String,
      onsetAndProgress: map['onset_and_progress'] as String?,
      pastHistory: map['past_history'] as String?,
      familyHistory: map['family_history'] as String?,
      personalHistory: map['personal_history'] as String?,
      thermalRelation: map['thermal_relation'] as String?,
      appetiteAndThirst: map['appetite_and_thirst'] as String?,
      desiresAndAversions: map['desires_and_aversions'] as String?,
      sweatAndUrineStool: map['sweat_and_urine_stool'] as String?,
      sleepAndDreams: map['sleep_and_dreams'] as String?,
      tongueAndBreath: map['tongue_and_breath'] as String?,
      mindAndDisposition: map['mind_and_disposition'] as String?,
      intellectAndMemory: map['intellect_and_memory'] as String?,
      fearsAndAnxieties: map['fears_and_anxieties'] as String?,
      miasmaticDominance: map['miasmatic_dominance'] as String?,
      constitutionalType: map['constitutional_type'] as String?,
      selectedRemedyChronic: map['selected_remedy_chronic'] as String?,
      potencyScale: map['potency_scale'] as String?,
      remedyDosageInstructions: map['remedy_dosage_instructions'] as String?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'case_id_fk': caseIdFk,
      'presenting_illness': presentingIllness,
      'onset_and_progress': onsetAndProgress,
      'past_history': pastHistory,
      'family_history': familyHistory,
      'personal_history': personalHistory,
      'thermal_relation': thermalRelation,
      'appetite_and_thirst': appetiteAndThirst,
      'desires_and_aversions': desiresAndAversions,
      'sweat_and_urine_stool': sweatAndUrineStool,
      'sleep_and_dreams': sleepAndDreams,
      'tongue_and_breath': tongueAndBreath,
      'mind_and_disposition': mindAndDisposition,
      'intellect_and_memory': intellectAndMemory,
      'fears_and_anxieties': fearsAndAnxieties,
      'miasmatic_dominance': miasmaticDominance,
      'constitutional_type': constitutionalType,
      'selected_remedy_chronic': selectedRemedyChronic,
      'potency_scale': potencyScale,
      'remedy_dosage_instructions': remedyDosageInstructions,
    };
  }
}