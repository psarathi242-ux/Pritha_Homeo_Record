class ChamberSettingsModel {
  final int? id;
  final String doctorName;
  final String? degrees;
  final String chamberName;
  final String? address;
  final String? phone;
  final String? email;
  final String? logoPath; // লোগো ফাইলের পাথ (যেমন: /data/user/0/.../logo.png)
  final String? prescriptionFooter;

  ChamberSettingsModel({
    this.id,
    required this.doctorName,
    this.degrees,
    required this.chamberName,
    this.address,
    this.phone,
    this.email,
    this.logoPath,
    this.prescriptionFooter,
  });

  factory ChamberSettingsModel.fromMap(Map<String, dynamic> map) {
    return ChamberSettingsModel(
      id: map['id'] as int?,
      doctorName: map['doctor_name'] as String,
      degrees: map['degrees'] as String?,
      chamberName: map['chamber_name'] as String,
      address: map['address'] as String?,
      phone: map['phone'] as String?,
      email: map['email'] as String?,
      logoPath: map['logo_path'] as String?,
      prescriptionFooter: map['prescription_footer'] as String?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'doctor_name': doctorName,
      'degrees': degrees,
      'chamber_name': chamberName,
      'address': address,
      'phone': phone,
      'email': email,
      'logo_path': logoPath,
      'prescription_footer': prescriptionFooter,
    };
  }
}